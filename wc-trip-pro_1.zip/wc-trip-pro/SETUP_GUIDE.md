# ⚽ WC Trip Pro — Setup & Deployment Guide

## What's in the app
- `index.html` — The complete single-file web app (all HTML + CSS + JS)

---

## STEP 1 — Test Locally

1. **Save** `index.html` to a folder on your computer (e.g. `Desktop/wc-trip-pro/`)
2. **Open** the file directly in Chrome, Firefox, or Edge:
   - Double-click `index.html` → it opens in your browser
   - OR drag it into an open browser window
3. You can use **all features** locally — the only thing that won't work is:
   - Real PayPal payments (needs a live URL)
   - The "Copy Share Link" button (clipboard API needs HTTPS)

> **Tip:** Use the "Simulate Premium Unlock (Demo)" button to test all premium features without a real payment.

---

## STEP 2 — Add Your Real PayPal Client ID

1. Go to **https://developer.paypal.com**
2. Log in with your PayPal business account (or create one — it's free)
3. Go to **Apps & Credentials** → **Create App**
4. Name it `WC Trip Pro` → Select **Merchant** → Click Create
5. Copy your **Client ID** (it looks like: `AaBbCc123...`)
6. Open `index.html` in a text editor (Notepad, VS Code, etc.)
7. Find this line near the top:
   ```
   <script src="https://www.paypal.com/sdk/js?client-id=YOUR_PAYPAL_CLIENT_ID&currency=USD"></script>
   ```
8. Replace `YOUR_PAYPAL_CLIENT_ID` with your actual Client ID:
   ```
   <script src="https://www.paypal.com/sdk/js?client-id=AaBbCc123...&currency=USD"></script>
   ```
9. Save the file — the real PayPal buttons will now appear!

> ⚠️ **Important:** PayPal Sandbox vs Live
> - For testing: use your **Sandbox** Client ID
> - For real payments: switch to your **Live** Client ID
> - Change `&currency=USD` to your preferred currency if needed

---

## STEP 3 — Upload to GitHub Pages (Free Hosting)

### One-time setup:
1. Create a free account at **https://github.com**
2. Click **"New repository"**
3. Name it: `wc-trip-pro`
4. Set it to **Public**
5. Click **"Create repository"**

### Upload your file:
1. On your new repo page, click **"uploading an existing file"**
2. Drag your `index.html` file into the box
3. Click **"Commit changes"**

### Enable GitHub Pages:
1. Go to your repo → **Settings** → **Pages**
2. Under "Source", select **Deploy from a branch**
3. Branch: **main** · Folder: **/ (root)**
4. Click **Save**
5. Wait ~2 minutes, then visit:
   ```
   https://YOUR-GITHUB-USERNAME.github.io/wc-trip-pro/
   ```

Your app is now live! 🎉

---

## STEP 4 — Upload to Truehost / cPanel Hosting

1. Log in to your Truehost control panel
2. Go to **File Manager** → navigate to `public_html`
3. Click **Upload** → select your `index.html`
4. If you want it at the root of your domain, make sure it's in `public_html/`
5. Visit your domain — the app should load immediately!

> ℹ️ If you have an existing website, upload as `wc-trip.html` and access it at `yourdomain.com/wc-trip.html`

---

## STEP 5 — Custom Domain (Optional)

After deploying to GitHub Pages:
1. Buy a domain from Namecheap, GoDaddy, or Truehost (~$10/year)
2. In your GitHub repo → **Settings → Pages → Custom domain**
3. Enter your domain (e.g. `wctrippro.com`)
4. In your domain's DNS settings, add a CNAME record pointing to `yourusername.github.io`

---

## Testing Checklist

Before going live, verify these work:

- [ ] Homepage loads with match grid
- [ ] Can select up to 3 matches (free limit enforced)
- [ ] "Generate My Free Plan" creates cost summary + itinerary
- [ ] "Simulate Premium Unlock" reveals premium content + PDF export
- [ ] PDF downloads correctly
- [ ] "Save Plan" stores plan to My Plans
- [ ] "My Plans" page shows saved plans
- [ ] "2026 Schedule" page lists all matches
- [ ] "Savings Tips" page shows all tips
- [ ] Dark/Light mode toggle works
- [ ] Mobile layout looks good (test with browser DevTools → Responsive)
- [ ] PayPal buttons appear after adding real Client ID

---

## Future Improvements (moving to a proper backend)

### Short-term (no backend needed):
- Add more matches as FIFA releases the full fixture list
- Add more host cities and stadiums
- Integrate a real hotel API (Booking.com affiliate, Expedia)
- Add Google Maps embeds for each stadium
- Add real flight price API (Skyscanner, Kiwi.com)

### Medium-term (simple backend — Node.js / PHP):
- **User accounts** — so plans survive browser clearing
- **PayPal webhook verification** — server-side payment confirmation is more secure
- **Email the PDF plan** to the user after purchase
- **Live ticket price tracker** — scrape StubHub / Ticketmaster for real resale prices
- **Team news feed** — FIFA API or RapidAPI soccer endpoints

### Long-term (full product):
- **Database** (Supabase, Firebase, or PostgreSQL) for user plans
- **Group Trip collaboration** — share a plan with friends to vote on matches
- **Price alerts** — email when hotel prices drop for selected cities
- **AI itinerary optimizer** — GPT-4 to suggest the most efficient travel routes
- **Affiliate revenue** — integrate Booking.com, GetYourGuide, Skyscanner affiliate links for passive income

---

## Revenue Model Suggestions

| Stream | How |
|--------|-----|
| Premium upgrades | PayPal one-time ($9.99 / $14.99) — already built |
| Hotel affiliate | Booking.com Partner Program (4–6% commission) |
| Flight affiliate | Skyscanner Affiliate (link out, earn per click) |
| Ticket resale | StubHub / SeatGeek affiliate links |
| Sponsored tips | Partner with travel insurance companies |

---

## Support & Questions

- To modify match data: find `const MATCHES = [` in the JS and edit the array
- To change prices: find `const COSTS = {` and update the values
- To add more savings tips: find `const ALL_TIPS = [` and add new tip objects
- To change PayPal amounts: search for `'9.99'` and `'14.99'` in the JS

---

*Built with ❤️ for World Cup 2026 fans. June 11 – July 19, 2026.*
